//Question pool
var shapeList ={
    '0':{
        '1': {topShape: {x: 60,y: 40},bottomShape: {x: 0,y: 0},points: [100,100,100, 200,200, 200,200, 100]},
        '2': {topShape: {x:-140,y: 0},bottomShape: {x:-40,y: 0},points: [300, 100, 300, 200, 400, 100]},
    },

    '1':{
        '1': {topShape: {x: 60,y: 0},bottomShape: {x: 0,y: 0},points: [100,100,100, 200,200, 200,200, 100]},
        '2': {topShape: {x:-100,y: 0},bottomShape: {x: -40,y: 0},points: [300, 100, 300, 200, 400, 100]},
        '3': {topShape: {x: 80,y: 0},bottomShape: {x: 40,y:140},points: [100,100,60, 140,100, 180,140, 140]},
    },

    '2':{
        '1': {topShape: {x: 40,y: 40},bottomShape: {x: 0,y: 0},points: [100,100,100, 200,200, 200,200, 100]},
        '2': {topShape: {x:-100,y: 0},bottomShape: {x: 0,y: 0},points: [300, 100, 300, 200, 400, 100]},
        '3': {topShape: {x: 60,y: -100},bottomShape: {x: 0,y: 0},points: [100, 300, 60, 340, 160, 340, 200, 300]},
    },

    '3': {
        '1': {topShape: {x: 50,y: -20},bottomShape: {x: 0,y: 0},points: [100,100,100, 200,200, 200,200, 100]},
        '2': {topShape: {x:-140,y:-20},bottomShape: {x: 0,y: 0},points: [300, 100, 300, 200, 400, 100]},
        '3': {topShape: {x: 80,y: -160},bottomShape: {x: 0,y: 0},points: [100, 300, 60, 340, 160, 340, 200, 300]},
    },

    '4': {
        '1': {topShape: {x: 40,y: -20},bottomShape: {x: 0,y: 0},points: [100,100,100, 200,200, 200,200, 100]},
        '2': {topShape: {x:-120,y:-20},bottomShape: {x: 0,y: 0},points: [300, 100, 300, 200, 400, 100]},
        '3': {topShape: {x: 40,y: -160},bottomShape: {x: 0,y: 0},points: [100, 300, 60, 340, 160, 340, 200, 300]},
    },


    '5': {
        '1': {topShape: {x: 20,y: 40},bottomShape: {x: 0,y: 0},points: [100,100,100, 200,200, 200,200, 100]},
        '2': {topShape: {x:-90,y: 110},bottomShape: {x: 0,y: 0},points: [300, 100, 300, 200, 400, 100]},
        '3': {topShape: {x: 60,y: -60},bottomShape: {x: 0,y: 0},points: [100, 300, 60, 340, 160, 340, 200, 300]},
    }



}